#version 330 core
layout(location = 0) out vec4 FragColor;

uniform vec4 color;

void main()
{
    FragColor = color;
    FragColor.a = 1.0;
} 
